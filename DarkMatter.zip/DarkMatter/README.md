# DarkMatter (Layer 7 DDoS) >> OLD VERSION << (New Version Release Has BEEN CANCELLED, Project IS NOT Maintained anymore)

Dark Matter is a Stresser that attacks on Layer 7, i have been developing this for a time... i guess it is one of the betters free-opensource DDoS Scripts. **(this is for testing purposes only or if you are allowed to perform the ddos attack)**

**USAGE:    Python3 DarkMatter.py**

**Features:**

**- DDoS Simulation: It can simulate a real DDoS with big power**

**- RateLimit bypass: It have 2 bypasses for rate-limiting**

**- Powerful: The power average is 900k requests and max. power is between 2Millions-6Millions requests depending on your VPS power, 1M is easy to reach with a common VPS**

**- OpenSource: It is 'opensource', then u can edit or use this to create ur own stresser**

**- Firewall Bypass: It have some firewall rules bypass**

**- Free: Free for download, Free for use... u dont need to pay anything**

**- No-Threads: It uses a different technology instead of threads, it means that it wont make ur computer burn and u dont need too much threads in your CPU**

**Requeriments to run:**

**- FIRST OF ALL: DONT RUN IN YOUR OWN MACHINE IF IT IS JUST A HOME-DESKTOP, HOME-LAPTOP OR ANY HOME-COMPUTER... IF UR MACHINE IS REALLY REALLY GOOD FOR THIS, TRY RUNNING THE ATTACK IN THIS MACHINE IN A REMOTEACCESS, OR U CANT SEE THE TRUE POWER**
---------------------------------------------
- 2+ cores CPU
- 400MBits/s Internet Speed **(Upload)**
- 1 GB Ram Free
- Recommended using VPS with linux, but u can use another OS (Windows), MAC is not recommended but it is up to you


The requeriments is not too much, right ?

If you want to see the PowerProof, this is here, below:
![image](https://user-images.githubusercontent.com/84208271/118342761-3988f500-b4fb-11eb-9d5b-bea2044993af.png)
(1000k is equivalent to 1Million)

Tested on a 2 cores machine with 900MBytes/s Upload


Creator: **xFactory**

Collaboration: **No one, i did it alone**

License: **MIT License**

MIT License:
>Copyright (c) 2021 xFactory
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to deal
> in the Software without restriction, including without limitation the rights
> to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
> copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
> OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
> THE SOFTWARE.
